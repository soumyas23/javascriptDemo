angular.module('pizzapp').controller('SignupCtrl',function($scope,getuser,$location){

$scope.save = function(user) {
    
    //console.log(user);
	getuser.register($scope.user,function(status)
		{
			$scope.status=status;
			 // console.log($scope.user);
			
		});
   $location.path("/login");

  };
});
