angular.module('pizzapp').factory('getuser',function($http) {

	var getuser = {
		register: function(user,callback){
                       $http({ method:'POST',
                               data:user,
                               headers: {'Content-Type': 'application/json'},
                               url:'http://localhost:3000/register'                                
                       }).success(function (data) {                        
                   callback(data);                
               });


	}
	

};
	return getuser;

});


