describe('getuser', function() {

  beforeEach(module('pizzapp'));

  it('should ...', inject(function(getuser) {

	//expect(getuser.doSomething()).toEqual('something');

  }));

});