describe('EmployeeService', function() {

  beforeEach(module('ui'));

  it('should ...', inject(function(EmployeeService) {

	//expect(EmployeeService.doSomething()).toEqual('something');

  }));

});